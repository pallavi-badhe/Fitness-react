import React, { Component } from "react";
 
class Logout extends Component {
  render() {
    return (
      <div>
  
      <div className="description text-center"><br/><br/><br/><br/>
     <marquee scrollamount="20"> <h1>  Thank You For Visiting Our Website ..!!</h1></marquee>
        <br/><br/>  
       <h1> <br/><a href='/home'>
    <button className="btn btn-outline-secondary btn-lg">Back to page</button> </a>  </h1>  
   </div>
   </div>
    );
  }
}
 
export default Logout;